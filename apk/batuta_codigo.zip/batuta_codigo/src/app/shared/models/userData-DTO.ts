export interface UserDataDTO {
  id: string;
  username: string;
  preferences: null;
}
