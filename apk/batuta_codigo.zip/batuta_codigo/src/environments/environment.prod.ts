export const environment = {
  production: true,
  supabaseUrl: 'https://ilybvqaifwjyrtislcqt.supabase.co',
  supabaseKey:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlseWJ2cWFpZndqeXJ0aXNsY3F0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzMxMzkwMjQsImV4cCI6MjA0ODcxNTAyNH0.gbE6ut4uSxvK__lQBNwrxqyptjOENwg7duJFrPCT5Ds',
};
